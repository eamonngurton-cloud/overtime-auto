package com.example.overtimeauto

import android.content.Context
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class Roster(val et: Set<String>, val lt: Set<String>, val nd: Set<String>, val off: Set<String>)
data class Decision(val number: String?, val note: String)

/** Settings + log storage */
object Store {
    private fun sp(c: Context) = c.getSharedPreferences("ot", Context.MODE_PRIVATE)
    fun get(c: Context, k: String, def: String) = sp(c).getString(k, def) ?: def
    fun set(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()

    private fun parseSet(s: String): Set<String> =
        s.split(Regex("[,;\\s]+")).mapNotNull { OvertimeEngine.normalise(it) }.toSet()

    // Defaults = the roster from your calendar. Edit in the app.
    fun roster(c: Context) = Roster(
        parseSet(get(c, "et", "26/10, 27/10, 5/11, 6/11, 14/11, 15/11, 16/11, 25/11, 26/11, 5/12")),
        parseSet(get(c, "lt", "28/10, 29/10, 30/10, 31/10, 7/11, 8/11, 18/11, 27/11, 28/11")),
        parseSet(get(c, "nd", "23/10, 24/10, 9/11, 10/11, 20/11, 29/11, 30/11")),
        parseSet(get(c, "off", "21/10, 1/11, 2/11, 3/11, 4/11, 19/11"))
    )

    fun log(c: Context, line: String) {
        val old = get(c, "log", "").lines().filter { it.isNotBlank() }.take(14)
        set(c, "log", (listOf(java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.UK)
            .format(java.util.Date()) + "  " + line) + old).joinToString("\n"))
    }
}

object OvertimeEngine {
    private const val MON = "jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec"
    private val months = MON.split("|")
    private val IC = RegexOption.IGNORE_CASE
    private val phoneRe = Regex("""(?:\+44|0)[\d ]{9,13}""")

    fun normalise(token: String): String? {
        val m = Regex("""^\s*(\d{1,2})/(\d{1,2})\s*$""").find(token) ?: return null
        return "${m.groupValues[1].toInt()}/${m.groupValues[2].toInt()}"
    }

    fun evaluate(body: String, roster: Roster, today: LocalDate): Decision {
        val isOt = Regex("overtime", IC).containsMatchIn(body) ||
            Regex("""\bOT\b""").containsMatchIn(body) || Regex("""\bOSE\b""").containsMatchIn(body)
        if (!isOt) return Decision(null, "Not an overtime text")
        val phone = phoneRe.find(body)?.value?.replace(" ", "") ?: return Decision(null, "No phone number found")
        val dates = findDates(body, today)
        if (dates.isEmpty()) return Decision(null, "No date found")
        val types = findTypes(body)
        if (types.isEmpty()) return Decision(null, "Couldn't tell which shift (ET/LT/ND)")
        for (d in dates) {
            if (d.isBefore(today)) continue
            for (t in types) if (can(d, t, roster)) return Decision(phone, "OK: $t on ${d.dayOfMonth}/${d.monthValue}")
        }
        return Decision(null, "Roster rules say no (${types.joinToString("/")} on ${dates.joinToString { "${it.dayOfMonth}/${it.monthValue}" }})")
    }

    private fun findDates(t: String, today: LocalDate): List<LocalDate> {
        val out = mutableListOf<LocalDate>()
        fun add(day: Int, month: Int, yearIn: Int?) {
            try {
                var y = yearIn ?: today.year
                if (yearIn == null) {
                    val d0 = LocalDate.of(y, month, day)
                    if (ChronoUnit.DAYS.between(d0, today) > 150) y++
                } else if (y < 100) y += 2000
                out.add(LocalDate.of(y, month, day))
            } catch (e: Exception) { /* invalid date, ignore */ }
        }
        fun mi(s: String) = months.indexOf(s.take(3).lowercase()) + 1

        // 27/10, 27/10/2026
        Regex("""\b(\d{1,2})[/.](\d{1,2})(?:[/.](\d{2,4}))?\b""").findAll(t).forEach {
            add(it.groupValues[1].toInt(), it.groupValues[2].toInt(), it.groupValues[3].toIntOrNull())
        }
        // Oct 27, October 27th
        Regex("""\b($MON)[a-z]*\.?\s+(\d{1,2})(?:st|nd|rd|th)?\b""", IC).findAll(t).forEach {
            add(it.groupValues[2].toInt(), mi(it.groupValues[1]), null)
        }
        // 27th October, 27 Oct, Wed 28th and Thu 29th October
        val pending = mutableListOf<Int>()
        Regex("""\b(\d{1,2})(?:st|nd|rd|th)\b|\b(\d{1,2})(?=\s*(?:of\s+)?(?:$MON)[a-z]*\b)|\b($MON)[a-z]*\b""", IC)
            .findAll(t).forEach {
                val g1 = it.groupValues[1]; val g2 = it.groupValues[2]; val g3 = it.groupValues[3]
                if (g1.isNotEmpty() || g2.isNotEmpty()) pending.add((g1.ifEmpty { g2 }).toInt())
                else { val mm = mi(g3); pending.forEach { d -> add(d, mm, null) }; pending.clear() }
            }
        if (Regex("""\b(today|tonight)\b""", IC).containsMatchIn(t)) out.add(today)
        if (Regex("""\btomorrow\b""", IC).containsMatchIn(t)) out.add(today.plusDays(1))
        return out
    }

    private fun findTypes(t: String): List<String> {
        val types = mutableListOf<String>()
        if (Regex("""\bnights?\b""", IC).containsMatchIn(t) || Regex("""\bN/?D\b""").containsMatchIn(t)) {
            types.add("ND")
        } else {
            if (Regex("""\bL/?T\b""").containsMatchIn(t) || Regex("""\blate (turn|duty)s?\b""", IC).containsMatchIn(t)) types.add("LT")
            if (Regex("""\bE/?T\b""").containsMatchIn(t) || Regex("""\bearly (turn|duty)s?\b""", IC).containsMatchIn(t)) types.add("ET")
        }
        if (types.isEmpty()) {
            if (Regex("""\b2[0-3]:?00\s*-\s*0?[5-7]:?00""").containsMatchIn(t)) types.add("ND")
            else if (Regex("""\b14:?00\s*-\s*2[23]:?00""").containsMatchIn(t)) types.add("LT")
            else if (Regex("""\b0?[67]:?00\s*-\s*1[5-6]:?00""").containsMatchIn(t)) types.add("ET")
        }
        return types
    }

    private fun shiftOn(d: LocalDate, r: Roster): String {
        val k = "${d.dayOfMonth}/${d.monthValue}"
        return when {
            k in r.off -> "X"
            k in r.nd -> "ND"
            k in r.lt -> "LT"
            k in r.et -> "ET"
            else -> ""
        }
    }

    /** Your rules */
    fun can(d: LocalDate, type: String, r: Roster): Boolean {
        val cur = shiftOn(d, r)
        if (cur == "X") return false
        if (type == "ET" && shiftOn(d.minusDays(1), r) == "ND") return false   // no night -> early
        if (type == "ND" && shiftOn(d.plusDays(1), r) == "ET") return false    // no night -> early
        if (type == "ND" && cur == "" && shiftOn(d.plusDays(1), r) != "") return false // no ND on last day off
        if (cur == "") return true                                              // free day: anything
        if (cur == "ET" && type == "LT") return true                            // early + late OK
        if (cur == "LT" && type == "ND") return true                            // late + night OK
        return false
    }
}
