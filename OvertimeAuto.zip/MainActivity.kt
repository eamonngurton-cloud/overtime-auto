package com.example.overtimeauto

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.time.LocalDate

class MainActivity : AppCompatActivity() {
    private lateinit var logView: TextView

    private fun label(t: String) = TextView(this).apply { text = t; textSize = 16f; setPadding(0, 32, 0, 8) }
    private fun edit(hint: String, value: String, lines: Int = 1) = EditText(this).apply {
        this.hint = hint; setText(value)
        if (lines > 1) { minLines = lines; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
    }
    private fun button(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        setContentView(ScrollView(this).apply { fitsSystemWindows = true; addView(root) })

        val sw = Switch(this).apply {
            text = "Overtime auto-responder ON"; textSize = 18f
            isChecked = Store.get(this@MainActivity, "enabled", "1") == "1"
        }
        root.addView(sw)

        root.addView(label("Your roster (dates as day/month, e.g. 26/10, 5/11)"))
        val etF = edit("Early turn dates (ET)", Store.get(this, "et", "26/10, 27/10, 5/11, 6/11, 14/11, 15/11, 16/11, 25/11, 26/11, 5/12"), 2)
        val ltF = edit("Late turn dates (LT)", Store.get(this, "lt", "28/10, 29/10, 30/10, 31/10, 7/11, 8/11, 18/11, 27/11, 28/11"), 2)
        val ndF = edit("Night duty dates (ND = the date the night STARTS)", Store.get(this, "nd", "23/10, 24/10, 9/11, 10/11, 20/11, 29/11, 30/11"), 2)
        val offF = edit("Unavailable days (leave, court, course)", Store.get(this, "off", "21/10, 1/11, 2/11, 3/11, 4/11, 19/11"), 2)
        listOf("Early (ET)" to etF, "Late (LT)" to ltF, "Night (ND)" to ndF, "Unavailable" to offF).forEach {
            root.addView(label(it.first)); root.addView(it.second)
        }

        root.addView(label("When overtime suits you:"))
        val group = RadioGroup(this)
        val rbCall = RadioButton(this).apply { text = "Call the number"; id = View.generateViewId() }
        val rbText = RadioButton(this).apply { text = "Text the number back"; id = View.generateViewId() }
        val rbBoth = RadioButton(this).apply { text = "Text if it's a mobile (07...), otherwise call"; id = View.generateViewId() }
        listOf(rbCall, rbText, rbBoth).forEach { group.addView(it) }
        when (Store.get(this, "action", "call")) {
            "text" -> rbText.isChecked = true
            "text_else_call" -> rbBoth.isChecked = true
            else -> rbCall.isChecked = true
        }
        root.addView(group)

        root.addView(label("Text-back message"))
        val replyF = edit("Message to send", Store.get(this, "reply", "Hi, I am available for this overtime. Please confirm."), 3)
        root.addView(replyF)

        root.addView(button("SAVE") {
            Store.set(this, "enabled", if (sw.isChecked) "1" else "0")
            Store.set(this, "et", etF.text.toString()); Store.set(this, "lt", ltF.text.toString())
            Store.set(this, "nd", ndF.text.toString()); Store.set(this, "off", offF.text.toString())
            Store.set(this, "action", when (group.checkedRadioButtonId) { rbText.id -> "text"; rbBoth.id -> "text_else_call"; else -> "call" })
            Store.set(this, "reply", replyF.text.toString())
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        })

        root.addView(label("Setup (do all three)"))
        root.addView(button("1. Allow SMS + phone permissions") {
            ActivityCompat.requestPermissions(this, arrayOf(
                Manifest.permission.RECEIVE_SMS, Manifest.permission.SEND_SMS, Manifest.permission.CALL_PHONE), 1)
        })
        root.addView(button("2. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(button("3. Battery: set this app to Unrestricted") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        root.addView(label("Test a text (nothing is called or sent)"))
        val testF = edit("Paste an overtime text here", "", 4)
        val result = TextView(this).apply { textSize = 15f }
        root.addView(testF)
        root.addView(button("TEST") {
            Store.set(this, "et", etF.text.toString()); Store.set(this, "lt", ltF.text.toString())
            Store.set(this, "nd", ndF.text.toString()); Store.set(this, "off", offF.text.toString())
            val r = OvertimeEngine.evaluate(testF.text.toString(), Store.roster(this), LocalDate.now())
            result.text = if (r.number != null) "WOULD ACT on ${r.number}\n${r.note}" else "WOULD IGNORE\n${r.note}"
        })
        root.addView(result)

        root.addView(label("Recent activity"))
        logView = TextView(this).apply { textSize = 13f }
        root.addView(logView)
    }

    override fun onResume() {
        super.onResume()
        logView.text = Store.get(this, "log", "Nothing yet")
    }
}
