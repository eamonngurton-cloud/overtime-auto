package com.example.overtimeauto

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.telecom.TelecomManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import java.time.LocalDate

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        if (Store.get(c, "enabled", "1") != "1") return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }

        val d = OvertimeEngine.evaluate(body, Store.roster(c), LocalDate.now())
        val num = d.number
        if (num == null) {
            if (d.note != "Not an overtime text") Store.log(c, "IGNORED: ${d.note}")
            return
        }

        val mode = Store.get(c, "action", "call")
        val isMobile = Regex("""^(\+44|0)7""").containsMatchIn(num)
        val doText = mode == "text" || (mode == "text_else_call" && isMobile)

        if (doText) {
            sendText(c, num, Store.get(c, "reply", "Hi, I am available for this overtime. Please confirm."))
            Store.log(c, "TEXTED $num (${d.note})")
        } else {
            call(c, num)
            Store.log(c, "CALLED $num (${d.note})")
        }
    }

    private fun has(c: Context, p: String) =
        ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    private fun call(c: Context, num: String) {
        if (!has(c, Manifest.permission.CALL_PHONE)) { Store.log(c, "NO CALL PERMISSION"); return }
        val uri = Uri.fromParts("tel", num, null)
        try {
            (c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).placeCall(uri, null)
        } catch (e: Exception) {
            try {
                c.startActivity(Intent(Intent.ACTION_CALL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e2: Exception) { Store.log(c, "CALL FAILED: ${e2.message}") }
        }
    }

    private fun sendText(c: Context, num: String, msg: String) {
        if (!has(c, Manifest.permission.SEND_SMS)) { Store.log(c, "NO SMS-SEND PERMISSION"); return }
        try {
            val sm = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java)
                     else @Suppress("DEPRECATION") SmsManager.getDefault()
            sm.sendMultipartTextMessage(num, null, sm.divideMessage(msg), null, null)
        } catch (e: Exception) { Store.log(c, "TEXT FAILED: ${e.message}") }
    }
}
